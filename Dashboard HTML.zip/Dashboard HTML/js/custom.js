(function ($) {
  'use strict';

  var LiveKeywordTable = $("body").find(".LiveKeywordTable table"),
    LiveKeywordTableRow = LiveKeywordTable.find("tr"),
    iconsList = LiveKeywordTableRow.find(".icons-list"),
    downArrow = iconsList.find(".downArrow"),
    compareDateForm = $("body").find(".compare-date-form"),
    compareDateRangeBtn = $("body").find("#compareDateRangeBtn"),
    compareDateToggle = $("body").find("#compareDateToggle"),
    compareDateInput = $("body").find("#compareDateInput");
  // ShareKeyBtn = $("body").find("#ShareKey"),
  //   CloseShareKey = $("body").find(".close-share-key");

  $(window).on("load", function () {
    setTimeout(function () {
      $('.loader').fadeOut(600, function () {
        $(this).remove();
      });
      $('.hiddenOnLoad').fadeIn(600, function () {
        $('div').removeClass("hiddenOnLoad");
      });

    }, 1000);
  });

  $("#AddKeywordsBtn").on("click", function () {
    $("body").find(".add-keywords-popup").toggleClass("open");
  });

  $(document).on("click", function (e) {
    if ($(e.target).is(".add-keywords-popup .add-keywords-popup-inner, #AddKeywordsBtn, .add-keywords-popup .add-keywords-popup-inner *") === false) {
      $(".add-keywords-popup").removeClass("open");
    }
  });

  $(document).ready(function () {
    $(".top-organic-keyword-table .table-responsive").mCustomScrollbar({
      axis: "y"
    });
    $(".sidebar nav ul.uk-nav-default:last-of-type .uk-nav-sub").mCustomScrollbar({
      axis: "y"
    });
    $(".project-table-body").mCustomScrollbar({
      axis: "x",
      setLeft: "-100px"
    });

    setTimeout(function () {
      $(".project-table-body .mCSB_container").css("left", 0);
    }, 2000);
  });

  LiveKeywordTableRow.each(function () {
    downArrow.on("click", function () {
      $(this).parent().toggleClass("active");
      $(this).find(".fa").toggleClass("fa-area-chart");
      $(this).find(".fa").toggleClass("fa-times");
    })
  });

  // ShareKeyBtn.on("click", function () {
  //   $(".share-key-popup").addClass("open");
  // });

  // CloseShareKey.on("click", function () {
  //   $(".share-key-popup").removeClass("open");
  // })

  // new ClipboardJS('.btn.share-key-btn');

  // $(".share-key-btn").on("click", function () {
  //   $(this).val("Copied!")
  // })

  $(".file-group input[type=file]").change(function () {
    var names = [];
    for (var i = 0; i < $(this).get(0).files.length; ++i) {
      names.push($(this).get(0).files[i].name);
    }

    if ($(".file-group input[type=file]").val()) {
      $(".file-group .form-control").addClass("selected");
      $(".file-group .form-control span").html(names);
    } else {
      $(".file-group .form-control").removeClass("selected");
      $(".file-group .form-control span").html("Profile Image");
    }

  });

  compareDateRangeBtn.on("click", function () {
    $(this).toggleClass("active");
    compareDateForm.toggleClass("open");
  })

  compareDateToggle.on("click", function () {
    if ($(this).is(":checked")) {
      compareDateInput.show(300);
    } else {
      compareDateInput.hide(200);
    }
  });


  $("[data-pd-popup-open]").on("click", function (e) {
    var targeted_popup_class = $(this).attr("data-pd-popup-open");
    $('[data-pd-popup="' + targeted_popup_class + '"]').fadeIn(100);
    $("body").addClass("popup-open");
    e.preventDefault();
  });

  $("[data-pd-popup-close]").on("click", function (e) {
    var targeted_popup_class = $(this).attr("data-pd-popup-close");
    $('[data-pd-popup="' + targeted_popup_class + '"]').fadeOut(200);
    $("body").removeClass("popup-open");
    e.preventDefault();
  });

  $(".circle_percent").each(function () {
    var $this = $(this),
      $dataV = $this.data("percent"),
      $dataDeg = $dataV * 3.6,
      $round = $this.find(".round_per");
    $round.css("transform", "rotate(" + parseInt($dataDeg + 180) + "deg)");
    $this.append('<div class="circle_inbox"><span class="percent_text"></span>of 100</div>');
    $this.prop('Counter', 0).animate({
      Counter: $dataV
    }, {
      duration: 2000,
      easing: 'swing',
      step: function (now) {
        $this.find(".percent_text").text(Math.ceil(now) + "");
      }
    });
    if ($dataV >= 51) {
      $round.css("transform", "rotate(" + 360 + "deg)");
      setTimeout(function () {
        $this.addClass("percent_more");
      }, 1000);
      setTimeout(function () {
        $round.css("transform", "rotate(" + parseInt($dataDeg + 180) + "deg)");
      }, 1000);
    }
  });


  $(".audit-box-body tbody.table-collapseed, .audit-box-body tbody.table-audit-collapseed").hide();

  $(".show-more-issues").on("click", function(){
    $(".audit-box-body tbody.table-collapseed").slideToggle();
    $(".show-more-issues").toggleClass("open");

    var Text = $(this).find("span.t")

    if(Text.text() == "Show More"){
      Text.text("Show Less");
    }
    else{
      Text.text("Show More");
    }

  })

  $(".show-more-audit-issues").on("click", function(){
    $(".audit-box-body tbody.table-audit-collapseed").slideToggle();
    $(".show-more-audit-issues").toggleClass("open");

    var Text = $(this).find("span.t")

    if(Text.text() == "Show More"){
      Text.text("Show Less");
    }
    else{
      Text.text("Show More");
    }

  })


  //Avoid pinch zoom on iOS
  document.addEventListener('touchmove', function (event) {
    if (event.scale !== 1) {
      event.preventDefault();
    }
  }, false);
})(jQuery)